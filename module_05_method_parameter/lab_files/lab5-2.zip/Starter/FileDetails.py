import sys

# To-do: 프로그램 인자로 파일 이름을 읽어들이는 코드 작성

# with open(file_name, "r") as file:
#    contents = list(file.read())