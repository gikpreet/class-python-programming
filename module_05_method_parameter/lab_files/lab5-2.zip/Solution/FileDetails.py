import sys

def summerize(contents):
    vowels, consonats, lines, total = 0, 0, 0, 0
    for s in contents:
        total += 1
        if s.isalpha():
            if s in "AEIOUaeiou":
                vowels += 1
            else:
                consonats += 1
        elif s == "\n":
            lines += 1
    print("총 문자 수:", total)
    print("모음 수:", vowels)
    print("자음 수:", consonats)
    print("라인 수:", lines)


if len(sys.argv) != 2:
    print("usage: python FileDetails.py FileName")
    exit()
else:
    file_name = sys.argv[1]

with open(file_name, "r") as file:
    contents = list(file.read())

summerize(contents)