import sys

def count_word(contents):
    for c,w in sorted((contents.count(w),w) for w in set(contents))[-1:-11:-1]:print(w,c)

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("usage: python FileDetails.py FileName")
        exit()
    else:
        file_name = sys.argv[1]

    with open(file_name, "r", encoding="UTF-8") as file:
        contents = file.read().split()

    count_word(contents)

# https://codingdojang.com/scode/634?langby=python

# https://eigenvector.tistory.com/35 