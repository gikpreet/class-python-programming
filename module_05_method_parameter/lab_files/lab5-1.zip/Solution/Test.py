import Utilities as util

# i = int(input("첫 번째 숫자를 입력하세요: "))
# j = int(input("두 번째 숫자를 입력하세요: "))

# max = util.max(i, j)

# print(max)

i = 1
j = 2 

print("함수 호출 전: ", i, j)
util.swap(i, j)
print("함수 호출 후: ", i, j)