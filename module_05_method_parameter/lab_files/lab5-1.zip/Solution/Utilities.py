def max(i, j):
    if i > j:
        return i
    else:
        return j
    
def swap(i, j):
    temp = i
    i = j
    j = temp