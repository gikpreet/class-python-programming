try:
    i = int(input("Enter first number: "))
    j = int(input("Enter second number: "))
    k = i / j

    print("%d / %d = %d" %(i, j, k))
except ZeroDivisionError as e:
    print("An Error was occured: ", e)