name = input("Enter your name: ")
age = int(input("Enter your age: "))
print("Greetings", name, age, "years old")