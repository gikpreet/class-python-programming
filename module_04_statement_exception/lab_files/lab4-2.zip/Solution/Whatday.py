days_in_month  = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
days_in_leap_month  = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
month_names = ["January", "Feburary", "March", "April", "May", "June", "July", "August", "Sepetember", "October", "November", "December"]

try:
    year_num = int(input("연도를 입력하세요: "))

    is_leap_year = (year_num % 4 == 0) and ((year_num % 100 != 0) or (year_num % 400 == 0))

    if (is_leap_year):
        max_day_num = 366
    else:
        max_day_num = 365

    day_num = int(input("1 에서 {} 사이의 숫자를 입력하세요: ".format(max_day_num)))

    if day_num < 1 or day_num > max_day_num:
        raise ValueError("범위를 벗어났습니다")

    month_num = 0

    if is_leap_year:
        for days in days_in_leap_month:
            if day_num <= days:
                break
            else:
                day_num -= days
                month_num += 1
    else:
        for days in days_in_month:
            if day_num <= days:
                break
            else:
                day_num -= days
                month_num += 1

    month_name = month_names[month_num]

    print(f"{day_num}, {month_name}")
except ValueError as e:
    print(e)
