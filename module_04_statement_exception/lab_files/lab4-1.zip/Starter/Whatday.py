days_in_month  = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
month_names = ["January", "Feburary", "March", "April", "May", "June", "July", "August", "Sepetember", "October", "November", "December"]

#
# To do: 숫자를 입력받는 코드를 추가합니다
#

'''
# Todo: if statement로 월 번호와 날짜를 계산합니다
if day_num > 31:    # Januray
    month_num += 1
    day_num -= 31

if day_num >= 28  :   # Feburary
    month_num +=  1
    day_num -= 28

if day_num >= 31:     # March
    month_num += 1
    day_num -= 31

if day_num >= 30:       # April
    month_num += 1
    day_num -= 30

if day_num >= 31:       # May
    month_num += 1
    day_num -= 31

if day_num >= 30:       # June
    month_num += 1
    day_num -= 30

if day_num >= 31:       # July
    month_num += 1
    day_num -= 31

if day_num >= 31:       # August
    month_num += 1
    day_num -= 31

if day_num >= 30:       # September
    month_num += 1
    day_num -= 30

if day_num >= 31:       # October
    month_num +=  1
    day_num -= 31
'''

'''
# match-case statement를 사용해서 월 이름을 할당합니다
match month_num:
    case 0:
        month_name = "January"
    case 1:
        month_name = "Feburary"
    case 2:
        month_name = "March"
    case 3:
        month_name = "April"
    case 4:
        month_name = "May"
    case 5:
        month_name = "June"
    case 6:
        month_name = "July"
    case 7:
        month_name = "August"
    case 8:
        month_name = "September"
    case 9:
        month_name = "October"
'''