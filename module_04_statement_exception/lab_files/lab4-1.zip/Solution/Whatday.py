days_in_month  = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
month_names = ["January", "Feburary", "March", "April", "May", "June", "July", "August", "Sepetember", "October", "November", "December"]

day_num = int(input("1 에서 365 사이의 숫자를 입력하세요: "))
month_num = 0

for days in days_in_month:
    if day_num <= days:
        break
    else:
        day_num -= days
        month_num += 1

month_name = month_names[month_num]

print(f"{day_num}, {month_name}")
