from decimal import Decimal

class CreateAccount:
    def create_new_account(self, account_number, name, balance):
        return BankAccount()
    
    def print_account(bank_account):
        pass

class BankAccount:
    pass
    # To-do write set data here