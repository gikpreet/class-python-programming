from Bank import BankAccount
from Bank import CreateAccount

if __name__ == "__main__":
    bank_account1 = CreateAccount.create_new_account("celine", 100.0)
    bank_account2 = CreateAccount.create_new_account("james", 200.0)
    CreateAccount.print_account(bank_account1)
    CreateAccount.print_account(bank_account2)