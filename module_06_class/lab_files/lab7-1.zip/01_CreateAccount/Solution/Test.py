from Bank import BankAccount
from Bank import CreateAccount

if __name__ == "__main__":
    bank_account = CreateAccount.create_new_account(1, "celine", 100.0)
    CreateAccount.print_account(bank_account)
