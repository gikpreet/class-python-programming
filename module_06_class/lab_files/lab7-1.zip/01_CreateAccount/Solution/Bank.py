from decimal import Decimal

class CreateAccount:
    def create_new_account(account_number, name, balance):
        account = BankAccount()
        account.set_data(account_number, name, balance)
        return account
    
    def print_account(bank_account):
        print(bank_account._account_number, end=", ")
        print(bank_account._name, end=", ")
        print(bank_account._balance)

class BankAccount:
    def set_data(self, account_number, name, balance):
        self._account_number = account_number
        self._name = name
        self._balance = Decimal(balance)