from Bank import BankAccount
from Bank import CreateAccount

if __name__ == "__main__":
    bank_account = CreateAccount.create_new_account()
    print(bank_account)
